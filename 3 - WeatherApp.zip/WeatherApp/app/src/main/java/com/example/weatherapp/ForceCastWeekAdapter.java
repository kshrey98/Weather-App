package com.example.weatherapp;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

public class ForceCastWeekAdapter extends RecyclerView.Adapter<ForecastWeekViewHolder> {

    private final List<Day> foreCastDailyContainer_forecast_List;
    private ForecastWeeklyActivity forecastWeeklyActivity;
    private String unit = "";
    private WeatherInfo weatherInfo;

    public ForceCastWeekAdapter(List<Day> foreCastDailyContainer_forecast_List, ForecastWeeklyActivity forecastWeeklyActivity, String unit, WeatherInfo weatherDetailsContainer) {
        Log.e("This is next activity adapter","atless");
        this.foreCastDailyContainer_forecast_List = foreCastDailyContainer_forecast_List;
        this.forecastWeeklyActivity = forecastWeeklyActivity;
        this.unit = unit;
        this.weatherInfo = weatherDetailsContainer;
      //  Toast.makeText(forecastWeeklyActivity, "This is next activity", Toast.LENGTH_LONG).show();
    }

    @NonNull
    @Override
    public ForecastWeekViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Log.e("new issue", "parseCurrentRecord: CANNOT FIND ICON "+"oncreateViewholder");
        View inflatedLayout = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.daily_weather_activity, parent, false);

        return new ForecastWeekViewHolder(inflatedLayout);

    }

    @Override
    public void onBindViewHolder(@NonNull ForecastWeekViewHolder holder, int position) {
        Log.e("new issue", "parseCurrentRecord: CANNOT FIND ICON "+"onbindViewholder");
        Day foreCastDailyContainer = foreCastDailyContainer_forecast_List.get(position);

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            LocalDateTime localDateTime = LocalDateTime.ofEpochSecond(foreCastDailyContainer.getDay_date_time() +
                            weatherInfo.getTimeZoneOffset(), 0, ZoneOffset.UTC);
        }

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("EEEE, MM/dd", Locale.getDefault());
        }

        holder.weeklyForecastTime.setText(Helper.convert_DateEpoch_to_dayDateString(foreCastDailyContainer.getDay_date_time()));


        String foreCastDailyContainerForecastTempRange = String.format("%s / %s", foreCastDailyContainer.getDay_temp_max() +
                        Helper.formatUnit(unit), foreCastDailyContainer.getDay_temp_min() +
                        Helper.formatUnit(unit));
        holder.weeklyForecastTemp.setText(""+foreCastDailyContainer.getDay_temp_max()+Helper.formatUnit(this.unit)+"/"+foreCastDailyContainer.getDay_temp_min()+Helper.formatUnit(this.unit));

        holder.weeklyForecastWeatherDesc.setText(foreCastDailyContainer.getDay_desc());

        String foreCastDailyContainerForecastPrecipitation = String.format("(%s%% precip.)",
                foreCastDailyContainer.getDay_precipprob());
        String prec = "("+foreCastDailyContainer.getDay_precipprob()+"% precip.)";
        holder.weeklyForecastPrecipitation.setText(prec);

        String foreCastDailyContainerForecastUvi = String.format("UV Index: %s", foreCastDailyContainer.getDay_uvindex());
       // holder.weeklyForecastUvi.setText(foreCastDailyContainer.getDay_uvindex());
        holder.weeklyForecastUvi.setText("UV Index: "+foreCastDailyContainer.getDay_uvindex());
        String iconCode =  foreCastDailyContainer.getIcon();

        iconCode = iconCode.replace("-","_");
         //iconCode= "partly_cloudy_day";
        // int img_res = getResources().getIdentifier("@drawable/"+iconCode, null, getPackageName());
        // Drawable dr = getResources().getDrawable(img_res);
        //currentWeatherIcon.setImageDrawable(dr);
        int iconID = forecastWeeklyActivity.getResources().getIdentifier(iconCode, "drawable", forecastWeeklyActivity.getPackageName());
        if (iconID == 0)
        {
            Log.e("new issue", "parseCurrentRecord: CANNOT FIND ICON "+iconCode);
        }
        else
        {
            holder.weeklyForecastWeatherIcon.setImageResource(iconID);
           // Log.e("CUR ICON CODE",""+ currentTempData.getCur_icon());
        }
//        holder.weeklyForecastWeatherIcon.setImageResource(forecastWeeklyActivity.getResources().
//                getIdentifier(iconCode, "drawable", forecastWeeklyActivity.getPackageName()));

        String foreCastDailyContainerForecastMorningTemperature = String.format("%s%s",
                foreCastDailyContainer.getHours_details_list().get(8).getHour_temp(), Helper.formatUnit(unit));
        holder.weeklyForecastMorningTemperature.setText(foreCastDailyContainerForecastMorningTemperature);

        String foreCastDailyContainerForecastDayTemperature = String.format("%s%s",
                foreCastDailyContainer.getHours_details_list().get(13).getHour_temp(), Helper.formatUnit(unit));
        holder.weeklyForecastAfternoonTemperature.setText(foreCastDailyContainerForecastDayTemperature);

        String foreCastDailyContainerForecastEveningTemperature = String.format("%s%s",
                foreCastDailyContainer.getHours_details_list().get(17).getHour_temp(), Helper.formatUnit(unit));
        holder.weeklyForecastEveningTemperature.setText(foreCastDailyContainerForecastEveningTemperature);

        String foreCastDailyContainerForecastNightTemperature = String.format("%s%s",
                foreCastDailyContainer.getHours_details_list().get(23).getHour_temp(), Helper.formatUnit(unit));
        holder.weeklyForecastNightTemperature.setText(foreCastDailyContainerForecastNightTemperature);

        holder.weeklyForecastMorningTime.setText("Morning");
        holder.weeklyForecastAfternoonTime.setText("Day");
        holder.weeklyForecastEveningTime.setText("Evening");
        holder.weeklyForecastNightTime.setText("Night");


    }

    @Override
    public int getItemCount() {

        Log.e("new issue", "parseCurrentRecord: CANNOT FIND ICON "+"getItemCount");
        return foreCastDailyContainer_forecast_List.size();
    }
}

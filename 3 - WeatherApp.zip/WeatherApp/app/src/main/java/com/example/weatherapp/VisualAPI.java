package com.example.weatherapp;

import android.app.Activity;
import android.util.Log;

import com.android.volley.RequestQueue;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class VisualAPI {
    private static final String TAG = "WEATHER API CLASS";


    /* API KEY */
    private static final String APIKEY = "FP54KHM4VJTBMGN7YW4FW3BTZ";

    //Weather URL
    private static final String URL_TO_VISUAL_CROSS_WEATHER_API_SLICE_1 = "https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/";
    private static final String location_string = "Chicago, IL"; /* default location */
    private static final String unit_group = "us";
    private static final String URL_TO_VISUAL_CROSS_WEATHER_API_SLICE_2 = "?unitGroup=";
    private static final String URL_TO_VISUAL_CROSS_WEATHER_API_SLICE_3 ="&lang=en&key=";
    private static final String URL_WEATHER_API = URL_TO_VISUAL_CROSS_WEATHER_API_SLICE_1+location_string+URL_TO_VISUAL_CROSS_WEATHER_API_SLICE_2+unit_group+URL_TO_VISUAL_CROSS_WEATHER_API_SLICE_3+APIKEY;



    // Volley Queue
    private static RequestQueue queue;

    private static WeatherInfo weatherInfo;

    public static WeatherInfo parseJSON(String s , Activity ae) {
        try{
            JSONObject jsonObject = new JSONObject(s);
            String address = jsonObject.getString("address");
            String timeZone = jsonObject.getString("timezone");
            long timezone_offset = jsonObject.getLong("tzoffset");
            long cur_dateTimeepoch = 0;
            //Toast.makeText(ae.getApplicationContext(),"add"+address+"time"+timeZone+"offset"+timezone_offset)

            // Parsing Current Data Temperature
            CurrentInfo currentInfo = null;
            if (jsonObject.has("currentConditions")){

                JSONObject currentObj = jsonObject.getJSONObject("currentConditions");


                String cur_date_string = null ;
                if(currentObj.has("datetimeEpoch")&& !currentObj.isNull("datetimeEpoch")) {
                    cur_dateTimeepoch = currentObj.getLong("datetimeEpoch");
                    cur_date_string = Helper.convert_DateEpoch_to_fullDateString(cur_dateTimeepoch);
                }

                double cur_temperature = 0;
                if(currentObj.has("temp")&& !currentObj.isNull("temp")) {
                    cur_temperature = currentObj.getDouble("temp");
                }

                double cur_feelslike = 0;
                if(currentObj.has("feelslike")&& !currentObj.isNull("feelslike")) {
                    cur_feelslike = currentObj.getDouble("feelslike");
                }
                double cur_humidity = 0;
                if(currentObj.has("humidity")&& !currentObj.isNull("humidity")) {
                    cur_humidity = currentObj.getDouble("humidity");
                }

                double cur_wind_gust = 0;
                if(currentObj.has("windgust") && !currentObj.isNull("windgust")) {
                    cur_wind_gust = currentObj.getDouble("windgust");
                }
                double cur_wind_speed = 0;
                if(currentObj.has("windspeed")&& !currentObj.isNull("windspeed")) {
                    cur_wind_speed = currentObj.getDouble("windspeed");
                }
                double cur_wind_dir = 0;
                if(currentObj.has("winddir")&& !currentObj.isNull("winddir")) {
                    cur_wind_dir = currentObj.getDouble("winddir");
                }

                double cur_visibility = 0;
                if(currentObj.has("visibility")&& !currentObj.isNull("visibility")) {
                    cur_visibility = currentObj.getDouble("visibility");
                }
                int cur_cloud_cover = 0;
                if(currentObj.has("cloudcover")&& !currentObj.isNull("cloudcover")) {
                    cur_cloud_cover = currentObj.getInt("cloudcover");
                }
                int cur_uv_index = 0;
                if(currentObj.has("uvindex")&& !currentObj.isNull("uvindex")) {
                    cur_uv_index = currentObj.getInt("uvindex");
                }
                String cur_conditions = null;
                if(currentObj.has("conditions")&& !currentObj.isNull("conditions")) {
                    cur_conditions = currentObj.getString("conditions");
                }
                String cur_icon = null;
                if(currentObj.has("icon")&& !currentObj.isNull("icon")) {
                    cur_icon = currentObj.getString("icon");
                }
                long cur_sun_riseepoch = 0;
                String cur_sun_rise_string = null;
                if(currentObj.has("sunriseEpoch")&& !currentObj.isNull("sunriseEpoch")) {
                    cur_sun_riseepoch = currentObj.getLong("sunriseEpoch");
                    cur_sun_rise_string = Helper.convert_DateEpoch_to_timeString(cur_sun_riseepoch);
                }
                long cur_sun_seteepoch = 0;
                String cur_sun_set_string = null ;
                if(currentObj.has("sunsetEpoch")&& !currentObj.isNull("sunsetEpoch")) {
                    cur_sun_seteepoch = currentObj.getLong("sunsetEpoch");
                    cur_sun_set_string = Helper.convert_DateEpoch_to_timeString(cur_sun_seteepoch);
                }


                currentInfo = new CurrentInfo(
                        cur_date_string,
                       cur_temperature,
                        cur_feelslike,
                        cur_humidity,
                        cur_wind_gust,
                        cur_wind_speed,
                        cur_wind_dir,
                        cur_visibility,
                        cur_cloud_cover,
                        cur_uv_index,
                        cur_conditions,
                        cur_icon,
                        cur_sun_rise_string,
                        cur_sun_set_string
                );
            }

            List<Day> foreCastDailyContainerList = new ArrayList<>();
            if (jsonObject.has("days")) {
                JSONArray daysJsonArray = jsonObject.getJSONArray("days");
                for (int i = 0; i < daysJsonArray.length(); i++) {
                    JSONObject day_item = daysJsonArray.getJSONObject(i);
                    JSONArray forecastHoursdataJsonArray = day_item.getJSONArray("hours");
                    List<Hour> hourList = new ArrayList<>();
                    Log.e("Loop in Days : ", ""+i);

                    for (int j = 0; j < forecastHoursdataJsonArray.length(); j++) {
                        Log.e("Loop in Days hours : ", ""+j);
                            JSONObject hour = forecastHoursdataJsonArray.getJSONObject(j);
                        Hour hour_data = new Hour(Helper.convert_DateEpoch_to_dayDateString(hour.getLong("datetimeEpoch")),
                                hour.getDouble("temp"),
                                hour.getString("conditions"),
                                hour.getString("icon"),
                                hour.getLong("datetimeEpoch")
                        );

                        hourList.add(j,hour_data);

                    }
                    Log.e("Hour list completed : ", hourList.toString());

                    Day day = new Day(day_item.getLong("datetimeEpoch"),
                            day_item.getDouble("tempmax"),
                            day_item.getDouble("tempmin"),
                            day_item.getInt("precipprob"),
                            day_item.getInt("uvindex"),
                            day_item.getString("description"),
                            day_item.getString("icon"),
                            hourList
                            );


                    foreCastDailyContainerList.add(i,day);
                }

                Log.e("Final list completed : ", foreCastDailyContainerList.toString());
            }


         ///   List<Day> foreCastDailyContainerList = new ArrayList<>();
            int counter = -1;
            List<Hour> hourList_forecast = new ArrayList<>();
            if (jsonObject.has("days")) {
                JSONArray daysJsonArray_2 = jsonObject.getJSONArray("days");
                for (int i = 0; i <4 ; i++) {
                    JSONObject day_item_1 = daysJsonArray_2.getJSONObject(i);
                    JSONArray forecastHoursdataJsonArray_2 = day_item_1.getJSONArray("hours");
                    for (int j = 0; j < forecastHoursdataJsonArray_2.length(); j++)
                    {

                         JSONObject hour_2 = forecastHoursdataJsonArray_2.getJSONObject(j);
                         long temp_jon_hour = hour_2.getLong("datetimeEpoch");
                         String hour_string = Helper.convert_DateEpoch_to_dayDateString(temp_jon_hour);
                         String cur_string = Helper.convert_DateEpoch_to_dayDateString(cur_dateTimeepoch);
                        String hour_string_day = hour_string.substring(0,hour_string.length()-6);
                        String cur_string_day  =   cur_string.substring(0,hour_string.length()-6);
                        String hour_string_num_day =  hour_string.substring(hour_string.length()-6).trim();
                        String cur_string_num_day =  cur_string.substring(hour_string.length()-6).trim();
                         String res = "";

                         if(hour_string_day.equalsIgnoreCase(cur_string_day))
                         {
                             //Toast.makeText(ae, "i"+i+"j"+j+"Cur string"+cur_string+"hourstring"+hour_string,Toast.LENGTH_LONG).show();
                             res = "Today";
                         }
                         else
                         {
                             res = hour_string.substring(0,hour_string.length()-6);
                             //res = "Not";
                         }


                        boolean he = Helper.convert_DateEpoch_to_time(temp_jon_hour).after(Helper.convert_DateEpoch_to_time(cur_dateTimeepoch));
                        // if (Helper.convert_DateEpoch_to_time(cur_dateTimeepoch).after(Helper.convert_DateEpoch_to_time(temp_jon_hour))) {
                           if(he) {
                               Log.e("The time after", Helper.convert_DateEpoch_to_timeString(temp_jon_hour));
                               Log.e("The time cur", Helper.convert_DateEpoch_to_timeString(cur_dateTimeepoch));
                               Log.e("The time differ", temp_jon_hour + ":" + cur_dateTimeepoch);

                               Hour hour_data_2 = new Hour(res,
                                       hour_2.getDouble("temp"),
                                       hour_2.getString("conditions"),
                                       hour_2.getString("icon"),
                                       hour_2.getLong("datetimeEpoch")
                               );
                               if (counter>=0 ) {
                                   hourList_forecast.add(hour_data_2);
                               }

                               counter += 1;
                           }

                    }
                }


            }




            weatherInfo = new WeatherInfo(address, timeZone, timezone_offset, currentInfo, hourList_forecast, foreCastDailyContainerList);
            return weatherInfo;
        } catch (Exception e){
            e.printStackTrace();
            Log.e("error in parse",e.toString());
           // Toast.makeText(ae,e.toString(),Toast.LENGTH_LONG).show();
        }
        return weatherInfo;
    }
}

package com.example.weatherapp;

import static com.example.weatherapp.Helper.formatUnit;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String TAG = "MainActivity";
    private TextView dateTime, curTemp, curFeelsLike, weather_Desc, winds, humidity, uvindex, vis, curSunrise, curSunset,snow;
    private TextView morTemp, noonTemp, eveTemp, nightTemp, morTime, noonTime, eveTime, nightTime;
    RecyclerView recyclerView;
    private ImageView curIcon;
    private SwipeRefreshLayout refreshScreen;

    private static final String APIKEY = "QCF2CH4W4YW24XSRCDP4YZJVH";

    //Weather URL
    private static final String URL_TO_VISUAL_CROSS_WEATHER_API_SLICE_1 = "https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/";
    private static String location_string = "Chicago, IL"; /* default location */
    private static  String unitGroup = "us";
    private static final String URL_TO_VISUAL_CROSS_WEATHER_API_SLICE_2 = "?unitGroup=";
    private static final String URL_TO_VISUAL_CROSS_WEATHER_API_SLICE_3 ="&lang=en&key=";
    private static final String URL_WEATHER_API = URL_TO_VISUAL_CROSS_WEATHER_API_SLICE_1+location_string+URL_TO_VISUAL_CROSS_WEATHER_API_SLICE_2+unitGroup+URL_TO_VISUAL_CROSS_WEATHER_API_SLICE_3+APIKEY;

    private WeatherInfo weatherInfo;
    private HourlyInfo hourlyInfo ;
    //String locationName="";
    private RequestQueue queue;
    // private static final String IMPERIAL = "imperial";
    private static final String METRIC = "metric";
    private String unit = unitGroup;
    private static final String MORNING = "Morning";
    private static final String AFTERNOON = "Afternoon";
    private static final String EVENING = "Evening";
    private static final String NIGHT= "Night";
    private MenuItem menuToggle;
    private List<Hour> hourList = new ArrayList<>();


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.setTitle(location_string);
        //getSavedContent();
        recyclerView = findViewById(R.id.recyclerview_cur_week);
        dateTime = findViewById(R.id.textview_cur_datetime);
        curTemp = findViewById(R.id.textview_cur_temp);
        curFeelsLike = findViewById(R.id.textview_cur_feelslike);
        weather_Desc = findViewById(R.id.textview_cur_weatherdesc);
        winds = findViewById(R.id.textview_winds);
        humidity = findViewById(R.id.textview_humdity);
        uvindex = findViewById(R.id.textview_UVIndex);
        vis = findViewById(R.id.textview_visiblity);
        curSunrise = findViewById(R.id.textview_cur_sunrise);
        curSunset = findViewById(R.id.textview_cur_sunset);
        morTemp = findViewById(R.id.textview_morn_num);
        noonTemp = findViewById(R.id.textview_afternoon_numb);
        eveTemp = findViewById(R.id.textview_evening_numb);
        nightTemp = findViewById(R.id.textview_night_numb);
        morTime = findViewById(R.id.textview_cur_morning_text);
        noonTime = findViewById(R.id.textview_cur_afternoon_text);
        eveTime = findViewById(R.id.textview_cur_evening_text);
        nightTime = findViewById(R.id.textview_cur_night_text);
        curIcon = findViewById(R.id.cur_Icon);
        // Swipe Refresh
        refreshScreen = findViewById(R.id.swipe_refresh);
        refreshScreen.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                getVisualData();
                refreshScreen.setRefreshing(false);
            }
        });

        getVisualData();
    }

    public String getVisualURL()
    {
        return URL_TO_VISUAL_CROSS_WEATHER_API_SLICE_1+this.location_string+URL_TO_VISUAL_CROSS_WEATHER_API_SLICE_2+this.unitGroup+URL_TO_VISUAL_CROSS_WEATHER_API_SLICE_3+APIKEY;
    }

    private String checkResponseForLocation(String passedString)
    {
        final String[] res = {"false"};
        RequestQueue queue2;
        queue2 = Volley.newRequestQueue(getApplicationContext());

        String urlwithunits = URL_TO_VISUAL_CROSS_WEATHER_API_SLICE_1+passedString+URL_TO_VISUAL_CROSS_WEATHER_API_SLICE_2+this.unit+URL_TO_VISUAL_CROSS_WEATHER_API_SLICE_3+APIKEY;
        JsonObjectRequest jsonObjectRequest =
                new JsonObjectRequest(Request.Method.GET, urlwithunits,
                        null, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {



                        res[0] = "true";
                        Log.e("Location valid",response.toString());



                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        res[0] = error.toString();


                    }
                });
        queue2.add(jsonObjectRequest);
        return res[0];
    }

    public boolean flag = false;
    private void getVisualData()
    {
        if (hasNetworkConnection()) {

            queue = Volley.newRequestQueue(getApplicationContext());


            JsonObjectRequest jsonObjectRequest =
                    new JsonObjectRequest(Request.Method.GET, getVisualURL(),
                            null, new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            FileOutputStream fos = null;
                            try {
                                fos = openFileOutput("test_log.txt", MODE_PRIVATE);
                                fos.write(response.toString().getBytes());
                                // Toast.makeText(HomeWeatherScreenActivity.this, "" + response.toString(), Toast.LENGTH_LONG).show();
                                Log.e("test", response.toString());

                            } catch (IOException e) {
                                e.printStackTrace();

                            }

                            weatherInfo = VisualAPI.parseJSON(response.toString(), MainActivity.this);
                            setWeatherInfo(weatherInfo);
                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(MainActivity.this, "Error ", Toast.LENGTH_LONG).show();
                            //dateAndTime.setText(String.format("%s", "No Network Connection"));
                            flag = true;
                        }
                    });

            // Add the request to the RequestQueue.
            queue.add(jsonObjectRequest);
        }
        else
        {
            dateTime.setText(String.format("%s", "No Network Connection"));
            curTemp.setText("");
            curFeelsLike.setText("");
            weather_Desc.setText("");
            winds.setText("");
            humidity.setText("");
            uvindex.setText("");
            snow.setText("");
            vis.setText("");
            morTemp.setText("");
            noonTemp.setText("");
            eveTemp.setText("");
            nightTemp.setText("");
            morTime.setText("");
            noonTime.setText("");
            eveTime.setText("");
            nightTime.setText("");
            curSunrise.setText("");
            curSunset.setText("");
            curIcon.setImageResource(0);
            hourList.clear();
            hourlyInfo = new HourlyInfo(hourList, this, weatherInfo, unit);
            recyclerView.setAdapter(hourlyInfo);
            recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        }
    }

    public void setWeatherInfo(WeatherInfo weatherInfo)
    {
        if (weatherInfo == null)
        {
            Toast.makeText(this, "", Toast.LENGTH_LONG).show();
            return;
        }
        CurrentInfo currentInfo = weatherInfo.getCurTempInfo();


        dateTime.setText(currentInfo.getCur_date_string());
        //  Toast.makeText(this, "CUR DATE STRUNG"+currentTempData.getCur_date_string(), Toast.LENGTH_LONG).show();
        Log.e("CUR DATE STRUNG",currentInfo.getCur_date_string());
        // Setting Current Temperature

        String format_units ;
        // "°C" : "°F"
        if (this.unit.equals("us") )
        {format_units = "°F";}
        else
        {
            format_units = "°C";

        }
        curTemp.setText(""+currentInfo.getCur_temperature()+format_units);
        Log.e("CUR DATE TEMP", String.valueOf(currentInfo.getCur_temperature()));
        // Setting Feels Like
        curFeelsLike.setText("Feels Like "+currentInfo.getCur_feelslike()+format_units);
        Log.e("CUR DATE FEELS LIKE",""+currentInfo.getCur_feelslike());
        // Weather Description
        weather_Desc.setText(""+currentInfo.getCur_conditions()+" "+"("+currentInfo.getCur_cloud_cover()+"% clouds)");
        Log.e("CUR Weather ","COND"+currentInfo.getCur_conditions()+"CLOUDCOVER"+currentInfo.getCur_cloud_cover());

        // Setting Winds
        String speed = "mph";
        String wind_gust_str = Helper.formatRangeperHour(this.unit,currentInfo.getCur_wind_gust());
        String wind_speed_str = Helper.formatRangeperHour(this.unit,currentInfo.getCur_wind_speed());
        winds.setText("Winds: "+Helper.getDirection(currentInfo.getCur_wind_dir())+" at "+wind_speed_str+" "+"gusting at "+wind_gust_str );
        Log.e("WINDS DIRE",""+currentInfo.getCur_wind_dir());
        Log.e("WINDS SPEED",""+currentInfo.getCur_wind_speed());
        Log.e("WINDS GUSTING",""+currentInfo.getCur_wind_gust());


        // Setting Humidity
        humidity.setText("Humidity: "+ currentInfo.getCur_humidity()+"%");
        Log.e("Humidity",""+currentInfo.getCur_humidity());
        // UVIndex
        uvindex.setText("UV Index: "+currentInfo.getCur_uv_index());
        Log.e("UVINDES",""+currentInfo.getCur_uv_index());

        // Setting Visibility - May get Error
        vis.setText("Visibility: " +
                //  HelperClass.formatRange(unit,(double) currentTempData.getVisibility()));
                Helper.formatRange(this.unit,currentInfo.getCur_visibility()));

        Log.e("VISIBI",""+ currentInfo.getCur_visibility());
        // ICon Code
        String iconCode = currentInfo.getCur_icon();
        iconCode = iconCode.replace("-","_");

        int iconID = getResources().getIdentifier(iconCode, "drawable", getPackageName());
        if (iconID == 0)
        {
            Log.d(TAG, "parseCurrentRecord: CANNOT FIND ICON "+iconCode);
        }
        else
        {
            curIcon.setImageResource(iconID);
            Log.e("CUR ICON CODE",""+ currentInfo.getCur_icon());
        }

        // Daily
        Day daily = weatherInfo.getDailyForecastList().get(0);
        double morning_hour = daily.getHours_details_list().get(8).getHour_temp();
        double afternoon_hour = daily.getHours_details_list().get(13).getHour_temp();
        double evening_hour = daily.getHours_details_list().get(17).getHour_temp();
        double night_hour = daily.getHours_details_list().get(23).getHour_temp();


        morTemp.setText( morning_hour+format_units);
        noonTemp.setText(afternoon_hour+format_units);
        eveTemp.setText(evening_hour+format_units);
        nightTemp.setText(night_hour+format_units);


        hourlyInfo = new HourlyInfo(weatherInfo.getHourlyList(), this, weatherInfo, unit);
        recyclerView.setAdapter(hourlyInfo);
        recyclerView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        setWeatherRecyclerData(weatherInfo.getHourlyList());

        curSunrise.setText("Sunrise: "+currentInfo.getCur_sun_rise_string());
        curSunset.setText("Sunrise: "+currentInfo.getCur_sun_set_string());
    }

    private void setWeatherRecyclerData(List<Hour> hourlyForecasts){
        this.hourList.addAll(hourlyForecasts);
        this.hourlyInfo.notifyDataSetChanged();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.weather_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (hasNetworkConnection()) {


            int menuID = item.getItemId();
            if (menuID == R.id.tempMenu) {
                // F to C and C to F call
                if (this.unit.equals("us")) {
                    this.unit = "metric";

                } else {
                    this.unit = "us";
                }
                setSavedContent();
                Helper.toggleUnit(menuToggle, this.unit);
                getVisualData();
                return true;
            }
            if (menuID == R.id.dailyForeMenu) {
                dailyActivity();

                return true;
            }
            if (menuID == R.id.LocMenu) {
                ChangeLoc();
                return true;
            }
        }
        else
        {
            Toast.makeText(this,"Function cannot be used as the network connection is broken at this time",Toast.LENGTH_LONG).show();
        }
        return super.onOptionsItemSelected(item);


    }

    private void changeTitle()
    {
        setTitle(this.location_string);
    }
    private void ChangeLoc() {
        if(hasNetworkConnection()) {
            LayoutInflater inflater = LayoutInflater.from(this);
            final View view = inflater.inflate(R.layout.location_dialogue, null);
            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            builder.setTitle("Enter a location");
            builder.setMessage("For US location, enter as 'City' or 'City, State' \n\n" + "For international locations enter as 'City, Country' ");
            builder.setView(view);
            builder.setPositiveButton("OK", (dialog, id) -> {
                EditText alertDialogLocation = view.findViewById(R.id.editText_location);

                String dialog_location_str = alertDialogLocation.getText().toString();

                if (dialog_location_str != null) {



                    this.location_string = dialog_location_str;
                    getVisualData();
                    if (flag == false)
                    {
                        changeTitle();
                        setSavedContent();
                    }
                    else
                    {
                        this.location_string = "Chicago, IL";
                        getVisualData();
                        this.setTitle(location_string);
                        setSavedContent();
                    }

                } else {
                    Toast.makeText(this, "Invalid city/state", Toast.LENGTH_SHORT).show();
                }
            });
            builder.setNegativeButton("CANCEL", (dialog, id) -> {
            });
            AlertDialog dialog = builder.create();
            dialog.show();
        } else {
            Toast.makeText(this, "No Network Connection", Toast.LENGTH_SHORT).show();
        }
    }

    public void dailyActivity() {

        Intent intent = new Intent(this, ForecastWeeklyActivity.class);
        intent.putExtra("weatherData", this.weatherInfo);
        intent.putExtra("temp_unit", this.unit);
        intent.putExtra("location", this.location_string);
        startActivity(intent);

    }

    private boolean hasNetworkConnection() {

        ConnectivityManager connectivityManager =  getSystemService(ConnectivityManager.class);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        return (networkInfo != null && networkInfo.isConnectedOrConnecting());
    }


    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        menuToggle = menu.findItem(R.id.tempMenu);
        Helper.toggleUnit(menuToggle, unit);
        return true;
    }

    @Override
    public void onClick(View view) {

        int pos = recyclerView.getChildLayoutPosition(view);
        Hour hourlyForecast = this.hourList.get(pos);

        LocalDateTime localDateTime =
                null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            localDateTime = LocalDateTime.ofEpochSecond(hourlyForecast.getHour_time() +
                    weatherInfo.getTimeZoneOffset(), 0, ZoneOffset.UTC);
        }

        Calendar cal = new GregorianCalendar();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            cal.setTime(Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant()));
        }
        Uri.Builder builder =
                CalendarContract.CONTENT_URI.buildUpon();
        builder.appendPath("time");

        builder.appendPath(Long.toString(cal.getTime().getTime()));
        Intent intent = new Intent(Intent.ACTION_VIEW, builder.build());
        startActivity(intent);


    }

    public void getSavedContent()
    {
        SharedPreferences sharedPreferences = getSharedPreferences("SAVED_WEATHER", Context.MODE_PRIVATE);
        String unit_of_temp = sharedPreferences.getString(String.valueOf(R.string.unit_of_temp), getString(R.string.saved_unit));
        String saved_location_string = sharedPreferences.getString(String.valueOf(R.string.saved_location_string), this.location_string);
        this.location_string = saved_location_string;
        this.unit = unit_of_temp;
    }
    public void setSavedContent() {
        SharedPreferences sharedPreferences = getSharedPreferences("SAVED_WEATHER", Context.MODE_PRIVATE);
        SharedPreferences.Editor sharedPreferencesEditor = sharedPreferences.edit();
        sharedPreferencesEditor.putString(String.valueOf(R.string.unit_of_temp), unit);
        sharedPreferencesEditor.putString(String.valueOf(R.string.saved_location_string), location_string);
        sharedPreferencesEditor.apply();
    }
}
package com.example.weatherapp;



import android.app.Activity;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.view.MenuItem;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;
import java.util.stream.Collectors;

public class Helper {
    private static final String METRIC = "metric";
    public static final String MORNING = "8am";
    public static final String DAY  ="1pm";
    public static final String EVENING ="5pm";
    public static final String NIGHT = "11pm";







    public static String capitalFirstChar(String text){
        String result = "";
        if (text == null || text.isEmpty()){
            return result;
        }

        return Arrays
                .stream(text.split(" "))
                .map(word -> word == null || word.isEmpty()
                        ? word
                        : word.substring(0, 1).toUpperCase() + word
                        .substring(1)
                        .toLowerCase())
                .collect(Collectors.joining(" "));
    }


    public static String convert_DateEpoch_to_fullDateString(long datetimeEpoch)
    {
        Date dateTime = new Date(datetimeEpoch * 1000); // Java time values need milliseconds
        SimpleDateFormat fullDate = new SimpleDateFormat("EEE MMM dd h:mm a, yyyy", Locale.getDefault());
        String fullDateStr = fullDate.format(dateTime); // Thu Sep 29 12:00 AM, 2022
        return  fullDateStr;
    }

    public static String convert_DateEpoch_to_timeString(long datetimeEpoch)
    {
        Date dateTime = new Date(datetimeEpoch * 1000); // Java time values need milliseconds
        SimpleDateFormat timeOnly = new SimpleDateFormat("h:mm a", Locale.getDefault());
        String timeOnlyStr = timeOnly.format(dateTime); // 12:00 AM
        return  timeOnlyStr;
    }
    public static Date convert_DateEpoch_to_time(long datetimeEpoch)
    {
        Date dateTime = new Date(datetimeEpoch * 1000); // Java time values need milliseconds
        SimpleDateFormat timeOnly = new SimpleDateFormat("h:mm a", Locale.getDefault());
        String timeOnlyStr = timeOnly.format(dateTime); // 12:00 AM
        return  dateTime;
    }

    public static String convert_DateEpoch_to_dayDateString(long datetimeEpoch)
    {
        Date dateTime = new Date(datetimeEpoch * 1000); // Java time values need milliseconds
        SimpleDateFormat dayDate = new SimpleDateFormat("EEEE MM/dd", Locale.getDefault());
        String dayDateStr = dayDate.format(dateTime); // Thursday 09/29
        return  dayDateStr;
    }
    public static String getDirection(Double degrees){
        if (degrees >= 337.5 || degrees < 22.5)
            return "N";
        if (degrees >= 22.5 && degrees < 67.5)
            return "NE";
        if (degrees >= 67.5 && degrees < 112.5)
            return "E";
        if (degrees >= 112.5 && degrees < 157.5)
            return "SE";
        if (degrees >= 157.5 && degrees < 202.5)
            return "S";
        if (degrees >= 202.5 && degrees < 247.5)
            return "SW";
        if (degrees >= 247.5 && degrees < 292.5)
            return "W";
        if (degrees >= 292.5 && degrees < 337.5)
            return "NW";
        return "X";
    }

    public static String formatRange(String unit, Double visibility) {

        return unit.equals(METRIC) ? String.format("%.1f km", visibility) :
                String.format("%.1f mi", visibility);
    }

    public static String formatRangeperHour(String unit, Double visibility) {

        return unit.equals(METRIC) ? String.format("%.1f kmph", visibility) :
                String.format("%.1f mph", visibility);
    }

    public static String formatUnit(String unit){
        return unit.equals("us") ? "°F" : "°C";
    }


    public static void toggleUnit(MenuItem homeMenuToggleUnits, String unit) {
        if (unit.equals(METRIC)) {
            homeMenuToggleUnits.setIcon(R.drawable.units_c);
        } else {
            homeMenuToggleUnits.setIcon(R.drawable.units_f);
        }
    }

}

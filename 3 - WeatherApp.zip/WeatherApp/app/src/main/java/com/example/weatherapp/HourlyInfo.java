package com.example.weatherapp;

import android.os.Build;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HourlyInfo extends RecyclerView.Adapter<ForeCastHourlyViewHolder> {

    private List<Hour> forecastsListHourlyContainer;
    private MainActivity mainActivity;
    private WeatherInfo weatherInfo;
    String unit = "";
    private static final String TAG = "RECYCLERVIEW_HOURLY";

    public HourlyInfo(List<Hour> forecastHourlyContainers, MainActivity mainActivity, WeatherInfo weatherInfo, String unit) {
        this.forecastsListHourlyContainer = forecastHourlyContainers;
        this.mainActivity = mainActivity;
        this.weatherInfo = weatherInfo;
        this.unit = unit;
    }

    @NonNull
    @Override
    public ForeCastHourlyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.hourly_forecast, parent,
                false);

        view.setOnClickListener(mainActivity);

        return new ForeCastHourlyViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull ForeCastHourlyViewHolder holder, int position) {
        Hour forecastHourlyContainer = forecastsListHourlyContainer.get(position);

        holder.day.setText(forecastHourlyContainer.getHour_date_time());
        //holder.time.setText(ldt.format(dtf));
        holder.time.setText(Helper.convert_DateEpoch_to_timeString(forecastHourlyContainer.getHour_time()));
        //holder.temperature.setText(String.format("%s%s", forecastHourlyContainer.getHour_date_time(), Helper.formatUnit(unit)));
        holder.temperature.setText(""+forecastHourlyContainer.getHour_temp()+Helper.formatUnit(this.unit));
        String iconCode =  forecastHourlyContainer.getHour_icon();
        iconCode = iconCode.replace("-","_");

        int iconID = mainActivity.getResources().getIdentifier(iconCode, "drawable", mainActivity.getPackageName());
        if (iconID == 0)
        {
            Log.d(TAG, "parseCurrentRecord: CANNOT FIND ICON "+iconCode);
        }
        else
        {  holder.weatherIcon.setImageResource(iconID);
            Log.e("CUR ICON CODE",""+ forecastHourlyContainer.getHour_icon());
        }

        holder.weatherDesc.setText(Helper.capitalFirstChar(forecastHourlyContainer.getHour_condition()));
    }

    @Override
    public int getItemCount() {
        return forecastsListHourlyContainer.size();
    }
}

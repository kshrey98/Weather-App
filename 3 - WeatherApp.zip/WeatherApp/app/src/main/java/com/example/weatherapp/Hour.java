package com.example.weatherapp;

import java.io.Serializable;

public class Hour implements Serializable {
    private String hour_date_time;
    private double hour_temp;
    private String hour_condition;
    private String hour_icon;
    private long hour_time;




    public Hour(String hour_date_time, double hour_temp , String hour_condition , String hour_icon , long hour_time) {
        this.hour_date_time = hour_date_time;
        this.hour_temp = hour_temp;
        this.hour_condition = hour_condition;
        this.hour_icon = hour_icon;
        this.hour_time = hour_time;
    }

    public long getHour_time() {
        return hour_time;
    }

    public void setHour_time(long hour_time) {
        this.hour_time = hour_time;
    }
    public String getHour_date_time() {
        return hour_date_time;
    }

    public void setHour_date_time(String hour_date_time) {
        this.hour_date_time = hour_date_time;
    }

    public double getHour_temp() {
        return hour_temp;
    }

    public void setHour_temp(double hour_temp) {
        this.hour_temp = hour_temp;
    }

    public String getHour_condition() {
        return hour_condition;
    }

    public void setHour_condition(String hour_condition) {
        this.hour_condition = hour_condition;
    }

    public String getHour_icon() {
        return hour_icon;
    }

    public void setHour_icon(String hour_icon) {
        this.hour_icon = hour_icon;
    }
}

package com.example.weatherapp;

import android.graphics.Bitmap;

import java.io.Serializable;
import java.util.List;

public class WeatherInfo implements Serializable {
    private String address;

    private String timeZone;

    private Long timeZoneOffset;

    private List<Hour> hourlyList;

    private List<Day> dailyForecastList;

    private Bitmap bitmap;

    private CurrentInfo currentInfo;

    public WeatherInfo(String address, String timeZone, Long timeZoneOffset,
                                   CurrentInfo currentInfo, List<Hour> hourlyList, List<Day> dailyForecastList) {

        this.address = address;
        this.timeZone = timeZone;
        this.timeZoneOffset = timeZoneOffset;
        this.currentInfo = currentInfo;
        this.hourlyList = hourlyList;
        this.dailyForecastList = dailyForecastList;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getTimeZone() {
        return timeZone;
    }

    public void setTimeZone(String timeZone) {
        this.timeZone = timeZone;
    }

    public Long getTimeZoneOffset() {
        return timeZoneOffset;
    }

    public void setTimeZoneOffset(Long timeZoneOffset) {
        this.timeZoneOffset = timeZoneOffset;
    }

    public CurrentInfo getCurTempInfo() {
        return currentInfo;
    }

    public void setCurrentTempData(CurrentInfo currentInfo) {
        this.currentInfo = currentInfo;
    }

    public List<Hour> getHourlyList() {
        return hourlyList;
    }

    public void setHourlyList(List<Hour> hourlyList) {
        this.hourlyList = hourlyList;
    }

    public List<Day> getDailyForecastList() {
        return dailyForecastList;
    }

    public void setDailyForecastList(List<Day> dailyForecastList) {
        this.dailyForecastList = dailyForecastList;
    }
}

package com.example.weatherapp;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


public class ForecastWeekViewHolder extends RecyclerView.ViewHolder {

    TextView weeklyForecastTime, weeklyForecastTemp,weeklyForecastWeatherDesc, weeklyForecastPrecipitation,weeklyForecastUvi
            ,weeklyForecastMorningTemperature,weeklyForecastAfternoonTemperature,weeklyForecastEveningTemperature,
            weeklyForecastMorningTime,weeklyForecastAfternoonTime, weeklyForecastEveningTime,weeklyForecastNightTime, weeklyForecastNightTemperature;
    ImageView weeklyForecastWeatherIcon;


    public ForecastWeekViewHolder(@NonNull View itemView) {
        super(itemView);
        weeklyForecastTime = itemView.findViewById(R.id.textView_time_of_day_forecast);
        weeklyForecastTemp = itemView.findViewById(R.id.textView_temp_of_day_forecast);
        weeklyForecastWeatherDesc = itemView.findViewById(R.id.textView_weather_description);
        weeklyForecastPrecipitation= itemView.findViewById(R.id.textView_humidity);
        weeklyForecastUvi = itemView.findViewById(R.id.textView_UV_index);

        weeklyForecastMorningTemperature= itemView.findViewById(R.id.textView_morning_num);
        weeklyForecastAfternoonTemperature = itemView.findViewById(R.id.textView_afternoon_num);
        weeklyForecastEveningTemperature = itemView.findViewById(R.id.textView_evening_num);
        weeklyForecastNightTemperature = itemView.findViewById(R.id.textView_night_num);

        weeklyForecastMorningTime = itemView.findViewById(R.id.textView_morning_text);
        weeklyForecastAfternoonTime = itemView.findViewById(R.id.textView_afternoon_text);
        weeklyForecastEveningTime = itemView.findViewById(R.id.textView_evening_text);
        weeklyForecastNightTime = itemView.findViewById(R.id.textView_night_text);

        weeklyForecastWeatherIcon = itemView.findViewById(R.id.imageView_weather_icon);

    }
}

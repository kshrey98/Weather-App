package com.example.weatherapp;

import java.io.Serializable;
import java.util.List;

public class Day implements Serializable {
    private long day_date_time;
    private double day_temp_max;
    private double day_temp_min;
    private int day_precipprob;
    private int day_uvindex;
    private String day_desc;
    private String icon;
    private List<Hour> hours_details_list;

    public Day( long day_date_time,
                double day_temp_max,
                double day_temp_min,
                int day_precipprob,
                int day_uvindex,
                String day_desc,
                String icon,
                List<Hour> hours_details_list) {
        this.day_date_time = day_date_time;
        this.day_temp_max = day_temp_max;
        this.day_temp_min = day_temp_min;
        this.day_precipprob = day_precipprob;
        this.day_uvindex = day_uvindex;
        this.day_desc = day_desc;
        this.icon = icon;
        this.hours_details_list = hours_details_list;
    }
    public long getDay_date_time() {
        return day_date_time;
    }

    public void setDay_date_time(long day_date_time) {
        this.day_date_time = day_date_time;
    }

    public double getDay_temp_max() {
        return day_temp_max;
    }

    public void setDay_temp_max(double day_temp_max) {
        this.day_temp_max = day_temp_max;
    }

    public double getDay_temp_min() {
        return day_temp_min;
    }

    public void setDay_temp_min(double day_temp_min) {
        this.day_temp_min = day_temp_min;
    }

    public int getDay_precipprob() {
        return day_precipprob;
    }

    public void setDay_precipprob(int day_precipprob) {
        this.day_precipprob = day_precipprob;
    }

    public int getDay_uvindex() {
        return day_uvindex;
    }

    public void setDay_uvindex(int day_uvindex) {
        this.day_uvindex = day_uvindex;
    }

    public String getDay_desc() {
        return day_desc;
    }

    public void setDay_desc(String day_desc) {
        this.day_desc = day_desc;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public List<Hour> getHours_details_list() {
        return hours_details_list;
    }

    public void setHours_details_list(List<Hour> hours_details_list) {
        this.hours_details_list = hours_details_list;
    }
}
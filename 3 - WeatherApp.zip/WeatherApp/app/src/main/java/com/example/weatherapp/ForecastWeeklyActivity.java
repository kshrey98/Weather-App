package com.example.weatherapp;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ForecastWeeklyActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private List<Day> dailyList = new ArrayList<>();
    private ForceCastWeekAdapter foreCastWeekAdapter;
    private WeatherInfo weatherInfo;
    private String unit;
    private String locale;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recycler_view_daily_forecast);
        recyclerView = findViewById(R.id.recyclerview_day_forecast);

        Intent intent = getIntent();



                if (intent.hasExtra("weatherData")
                && intent.hasExtra("temp_unit")
                && intent.hasExtra("location")) {

            this.weatherInfo = (WeatherInfo) intent.getSerializableExtra("weatherData");
            this.unit = (String) intent.getSerializableExtra("temp_unit");
            this.locale = intent.getStringExtra("location");
            this.setTitle(locale+ "15 Day");


            //if(WeatherDetailsContainer != null){
                this.dailyList.addAll(weatherInfo.getDailyForecastList());
                this.foreCastWeekAdapter = new ForceCastWeekAdapter(dailyList,
                        this, this.unit, this.weatherInfo);

            //}
            recyclerView.setAdapter(foreCastWeekAdapter);
            recyclerView.setLayoutManager(new LinearLayoutManager(this,
                    LinearLayoutManager.VERTICAL, false));
        }
    }
}
package com.example.weatherapp;

import java.io.Serializable;

public class CurrentInfo implements Serializable {

    private String cur_date_string;
    private double cur_temperature;
    private double cur_feelslike;
    private double cur_humidity;
    private double cur_wind_gust;
    private double cur_wind_speed;
    private double cur_wind_dir;
    private double cur_visibility;
    private int cur_cloud_cover;
    private int cur_uv_index;
    private String cur_conditions;
    private String cur_icon;
    private String cur_sun_rise_string;
    private String cur_sun_set_string;


    public String getCur_date_string() {
        return cur_date_string;
    }

    public void setCur_date_string(String cur_date_string) {
        this.cur_date_string = cur_date_string;
    }

    public double getCur_temperature() {
        return cur_temperature;
    }

    public void setCur_temperature(double cur_temperature) {
        this.cur_temperature = cur_temperature;
    }

    public double getCur_feelslike() {
        return cur_feelslike;
    }

    public void setCur_feelslike(double cur_feelslike) {
        this.cur_feelslike = cur_feelslike;
    }

    public double getCur_humidity() {
        return cur_humidity;
    }

    public void setCur_humidity(double cur_humidity) {
        this.cur_humidity = cur_humidity;
    }

    public double getCur_wind_gust() {
        return cur_wind_gust;
    }

    public void setCur_wind_gust(double cur_wind_gust) {
        this.cur_wind_gust = cur_wind_gust;
    }

    public double getCur_wind_speed() {
        return cur_wind_speed;
    }

    public void setCur_wind_speed(double cur_wind_speed) {
        this.cur_wind_speed = cur_wind_speed;
    }

    public double getCur_wind_dir() {
        return cur_wind_dir;
    }

    public void setCur_wind_dir(double cur_wind_dir) {
        this.cur_wind_dir = cur_wind_dir;
    }

    public double getCur_visibility() {
        return cur_visibility;
    }

    public void setCur_visibility(double cur_visibility) {
        this.cur_visibility = cur_visibility;
    }

    public int getCur_cloud_cover() {
        return cur_cloud_cover;
    }

    public void setCur_cloud_cover(int cur_cloud_cover) {
        this.cur_cloud_cover = cur_cloud_cover;
    }

    public int getCur_uv_index() {
        return cur_uv_index;
    }

    public void setCur_uv_index(int cur_uv_index) {
        this.cur_uv_index = cur_uv_index;
    }

    public String getCur_conditions() {
        return cur_conditions;
    }

    public void setCur_conditions(String cur_conditions) {
        this.cur_conditions = cur_conditions;
    }

    public String getCur_icon() {
        return cur_icon;
    }

    public void setCur_icon(String cur_icon) {
        this.cur_icon = cur_icon;
    }

    public String getCur_sun_rise_string() {
        return cur_sun_rise_string;
    }

    public void setCur_sun_rise_string(String cur_sun_rise_string) {
        this.cur_sun_rise_string = cur_sun_rise_string;
    }

    public String getCur_sun_set_string() {
        return cur_sun_set_string;
    }

    public void setCur_sun_set_string(String cur_sun_set_string) {
        this.cur_sun_set_string = cur_sun_set_string;
    }


    public CurrentInfo(String cur_date_string,
                                  double cur_temperature,
                                  double cur_feelslike,
                                  double cur_humidity,
                                  double cur_wind_gust,
                                  double cur_wind_speed,
                                  double cur_wind_dir,
                                  double cur_visibility,
                                  int cur_cloud_cover,
                                  int cur_uv_index,
                                  String cur_conditions,
                                  String cur_icon,
                                  String cur_sun_rise_string,
                                  String cur_sun_set_string
    ) {
        this.cur_date_string = cur_date_string;
        this.cur_temperature = cur_temperature;
        this.cur_feelslike = cur_feelslike;
        this.cur_humidity = cur_humidity;
        this.cur_wind_gust = cur_wind_gust;
        this.cur_wind_speed = cur_wind_speed;
        this.cur_wind_dir = cur_wind_dir;
        this.cur_visibility = cur_visibility;
        this.cur_cloud_cover = cur_cloud_cover;
        this.cur_uv_index = cur_uv_index;
        this.cur_conditions = cur_conditions;
        this.cur_icon = cur_icon;
        this.cur_sun_rise_string = cur_sun_rise_string;
        this.cur_sun_set_string = cur_sun_set_string;

    }
}

package com.example.weatherapp;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


public class ForeCastHourlyViewHolder extends RecyclerView.ViewHolder {

    TextView day;
    TextView time;
    ImageView weatherIcon;
    TextView temperature;
    TextView weatherDesc;

    public ForeCastHourlyViewHolder(@NonNull View itemView, TextView day, TextView time, ImageView weatherIcon, TextView temperature, TextView weatherDesc) {
        super(itemView);
        this.day = day;
        this.time = time;
        this.weatherDesc = weatherDesc;
        this.weatherIcon = weatherIcon;
        this.temperature = temperature;
    }

    public ForeCastHourlyViewHolder(View view) {
        super(view);
        day = view.findViewById(R.id.textView_today);
        time = view.findViewById(R.id.textView_time_day);
        weatherIcon = view.findViewById(R.id.imageView_icon);
        temperature = view.findViewById(R.id.textView_temp_num);
        weatherDesc = view.findViewById(R.id.textView_temp_desc);
    }

}
